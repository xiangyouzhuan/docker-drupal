<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, NULL, 'yu', 'tai', 'chan', 'man', 'min', 'huan', 'wen', 'nuan', 'huan', 'hou', 'jing', 'bo', 'xian', 'li',
  0x10 => 'jin', NULL, 'mang', 'piao', 'hao', 'yang', NULL, 'xian', 'su', 'wei', 'che', 'xi', 'jin', 'ceng', 'he', 'fen',
  0x20 => 'shai', 'ling', NULL, 'dui', 'qi', 'pu', 'yue', 'bo', NULL, 'hui', 'die', 'yan', 'ju', 'jiao', 'nan', 'lie',
  0x30 => 'yu', 'ti', 'tian', 'wu', 'hong', 'xiao', 'hao', NULL, 'tiao', 'zheng', NULL, 'huang', 'fu', NULL, NULL, 'tun',
  0x40 => NULL, 'reng', 'jiao', NULL, 'xin', NULL, NULL, 'yuan', 'jue', 'hua', NULL, 'bang', 'mou', NULL, 'gang', 'wei',
  0x50 => NULL, 'mei', 'si', 'bian', 'lu', 'qu', NULL, NULL, 'ge', 'zhe', 'lu', 'pai', 'rong', 'qiu', 'lie', 'gong',
  0x60 => 'xian', 'xi', 'xin', NULL, 'niao', NULL, NULL, NULL, 'xie', 'lie', 'fu', 'cuo', 'zhuo', 'ba', 'zuo', 'zhe',
  0x70 => 'zui', 'he', 'ji', NULL, 'jian', NULL, NULL, NULL, 'tu', 'xian', 'yan', 'tang', 'ta', 'di', 'jue', 'ang',
  0x80 => 'han', 'xiao', 'ju', 'wei', 'bang', 'zhui', 'nie', 'tian', 'nai', NULL, NULL, 'you', 'mian', NULL, NULL, 'nai',
  0x90 => 'sheng', 'cha', 'yan', 'gen', 'chong', 'ruan', 'jia', 'qin', 'mao', 'e', 'li', 'chi', 'zang', 'he', 'jie', 'nian',
  0xA0 => NULL, 'guan', 'hou', 'gai', NULL, 'ben', 'suo', 'wu', 'ji', 'xi', 'qiong', 'he', 'weng', 'xian', 'jie', 'hun',
  0xB0 => 'pi', 'shen', 'chou', 'zhen', NULL, 'zhan', 'shuo', 'ji', 'song', 'zhi', 'ben', NULL, NULL, NULL, 'lang', 'bi',
  0xC0 => 'xuan', 'pei', 'dai', NULL, 'zhi', 'pi', 'chan', 'bi', 'su', 'huo', 'hen', 'jiong', 'chuan', 'jiang', 'nen', 'gu',
  0xD0 => 'fang', NULL, NULL, 'ta', 'cui', 'xi', 'de', 'xian', 'kuan', 'zhe', 'ta', 'hu', 'cui', 'lu', 'juan', 'lu',
  0xE0 => 'qian', 'pao', 'zhen', NULL, 'li', 'cao', 'qi', NULL, NULL, 'ti', 'ling', 'qu', 'lian', 'lu', 'shu', 'gong',
  0xF0 => 'zhe', 'pao', 'jin', 'qing', NULL, NULL, 'zong', 'pu', 'jin', 'biao', 'jian', 'gun', NULL, NULL, 'zao', 'lie',
];
