<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'mou', 'ye', 'wei', 'xing', 'teng', 'zhou', 'shan', 'jian', 'po', 'kui', 'huang', 'huo', 'ge', 'ying', 'mi', 'xiao',
  0x10 => 'mi', 'xi', 'qiang', 'chen', 'xue', 'ti', 'su', 'bang', 'chi', 'qian', 'shi', 'jiang', 'yuan', 'xie', 'he', 'tao',
  0x20 => 'yao', 'yao', 'zhi', 'yu', 'biao', 'cong', 'qing', 'li', 'mo', 'mo', 'shang', 'zhe', 'miu', 'jian', 'ze', 'jie',
  0x30 => 'lian', 'lou', 'can', 'ou', 'gun', 'xi', 'zhuo', 'ao', 'ao', 'jin', 'zhe', 'yi', 'hu', 'jiang', 'man', 'chao',
  0x40 => 'han', 'hua', 'chan', 'xu', 'zeng', 'se', 'xi', 'zha', 'dui', 'zheng', 'nao', 'lan', 'e', 'ying', 'jue', 'ji',
  0x50 => 'zun', 'jiao', 'bo', 'hui', 'zhuan', 'wu', 'zen', 'zha', 'shi', 'qiao', 'tan', 'zen', 'pu', 'sheng', 'xuan', 'zao',
  0x60 => 'tan', 'dang', 'sui', 'xian', 'ji', 'jiao', 'jing', 'zhan', 'nang', 'yi', 'ai', 'zhan', 'pi', 'hui', 'hua', 'yi',
  0x70 => 'yi', 'shan', 'rang', 'nou', 'qian', 'zhui', 'ta', 'hu', 'zhou', 'hao', 'ai', 'ying', 'jian', 'yu', 'jian', 'hui',
  0x80 => 'du', 'zhe', 'xuan', 'zan', 'lei', 'shen', 'wei', 'chan', 'li', 'yi', 'bian', 'zhe', 'yan', 'e', 'chou', 'wei',
  0x90 => 'chou', 'yao', 'chan', 'rang', 'yin', 'lan', 'chen', 'xie', 'nie', 'huan', 'zan', 'yi', 'dang', 'zhan', 'yan', 'du',
  0xA0 => 'yan', 'ji', 'ding', 'fu', 'ren', 'ji', 'jie', 'hong', 'tao', 'rang', 'shan', 'qi', 'tuo', 'xun', 'yi', 'xun',
  0xB0 => 'ji', 'ren', 'jiang', 'hui', 'ou', 'ju', 'ya', 'ne', 'xu', 'e', 'lun', 'xiong', 'song', 'feng', 'she', 'fang',
  0xC0 => 'jue', 'zheng', 'gu', 'he', 'ping', 'zu', 'shi', 'xiong', 'zha', 'su', 'zhen', 'di', 'zhou', 'ci', 'qu', 'zhao',
  0xD0 => 'bi', 'yi', 'yi', 'kuang', 'lei', 'shi', 'gua', 'shi', 'ji', 'hui', 'cheng', 'zhu', 'shen', 'hua', 'dan', 'gou',
  0xE0 => 'quan', 'gui', 'xun', 'yi', 'zheng', 'gai', 'xiang', 'cha', 'hun', 'xu', 'zhou', 'jie', 'wu', 'yu', 'qiao', 'wu',
  0xF0 => 'gao', 'you', 'hui', 'kuang', 'shuo', 'song', 'ei', 'qing', 'zhu', 'zou', 'nuo', 'du', 'zhuo', 'fei', 'ke', 'wei',
];
